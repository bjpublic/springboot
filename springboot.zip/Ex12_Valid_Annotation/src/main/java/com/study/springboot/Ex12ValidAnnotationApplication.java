package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex12ValidAnnotationApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex12ValidAnnotationApplication.class, args);
	}

}
