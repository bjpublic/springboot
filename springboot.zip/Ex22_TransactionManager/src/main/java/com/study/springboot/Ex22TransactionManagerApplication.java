package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex22TransactionManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex22TransactionManagerApplication.class, args);
	}

}
