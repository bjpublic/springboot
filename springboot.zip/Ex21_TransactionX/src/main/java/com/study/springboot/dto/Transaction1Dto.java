package com.study.springboot.dto;

import lombok.Data;

@Data
public class Transaction1Dto {
    private String consumerId;
    private int amount;
}
