package com.study.springboot.dto;

import lombok.Data;

@Data
public class Transaction2Dto {
    private String consumerId;
    private int amount;
}
