package com.study.springboot;

import lombok.Data;

@Data
public class Member {
	private String id;
	private String name;	
}
