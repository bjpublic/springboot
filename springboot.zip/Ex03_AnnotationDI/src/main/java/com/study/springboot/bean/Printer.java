package com.study.springboot.bean;

public interface Printer {
    public void print(String message);
}
