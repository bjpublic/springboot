package com.study.springboot;

import lombok.Data;

@Data
public class ContentDto {
    private int id;
    private String writer;
    private String content;
}
